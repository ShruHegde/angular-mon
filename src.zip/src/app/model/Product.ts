export class Product {
    pid: number
    pname: string
    pqty:number
price:number
unit:string
cfk:number
    constructor() {
        this.pid = 0
        this.pname = ''
        this.pqty= 0
        this.price=0
        this.unit= ''
        this.cfk=0
    }
}
