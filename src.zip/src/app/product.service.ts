import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from './model/product';
import { User } from './model/User';
import { Injectable } from '@angular/core';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productStatus: boolean
  adminStatus: boolean
  currentUser: User
  public products: Product[]
  
  constructor(public http: HttpClient) {
    this.productStatus = false
    this.products = []
  }
  addProduct(product: Product) {
    return this.http.post('http://localhost:8555/grocery/product/save', product, httpOptions)
  }
  getProduct()
  {
    return this.http.get('http://localhost:8555/grocery/product/all', httpOptions)
  }
  
 
}
