import { Product } from '../model/product';
import { Component, OnInit } from '@angular/core';

import { Router, Event, NavigationEnd } from '@angular/router';
import { ProductService } from './../product.service';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  product:Product
  successFlag: boolean
  errorFlag: boolean
  products: Product[]
  progressFlag: boolean

  constructor(public prodService: ProductService, public router: Router) {
    this.initProduct()
    this.products=[]
  }

  ngOnInit() {
  }

  productSubmit(productForm) {

    this.successFlag = false
    this.errorFlag = false

    this.prodService.addProduct(this.product)
      .subscribe((res: Product) => {
        
        if (res !== null) {
          this.successFlag = true
          this.prodService.productStatus = true
          this.router.navigateByUrl('/product')
        }
        else {
          this.errorFlag = true
          this.prodService.productStatus = false
        }
      }, err => {
        console.log(err)
        this.errorFlag = true
        this.prodService.productStatus = false
      })
      
  }
 
  
  getProduct() {
    this.progressFlag = true
    this.prodService.getProduct()
      .subscribe((res: Product[]) => {
        if (res) {
          this.products = res
        }

        this.progressFlag = false

      })
  }

  
  initProduct() {
    this.product = {
      pid:0,
      pname: '',
      pqty:0,
      price:0,
      unit:'',
      cfk:0

    }
  }
}